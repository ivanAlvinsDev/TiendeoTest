import React from 'react';
import './Column.scss'
import { Droppable } from 'react-beautiful-dnd';
import classNames from 'classnames';
import Task from './../Task/Task'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons'

export default class Column extends React.Component {
	render() {
		return (
			<div className={classNames('column__container', `column__container--${this.props.column.color}`)}>
				<h3 className="column__title">{this.props.column.title}</h3>
				<Droppable droppableId={this.props.column.id}>
					{provided => (
						<div
						className="column__taskList"
						ref={provided.innerRef}
						{...provided.droppableProps}
						>
							{this.props.tasks.map((task, index) => (
								<Task key={task.id} task={task} index={index} />
							))}
							{provided.placeholder}
						</div>
					)}
				</Droppable>
				<button className="column__button">
					<a href="Add task button">Add task</a>
					<FontAwesomeIcon icon={faPlusCircle} />
				</button>
			</div>
		);
	}
}