import React from 'react';
import './Sidebar.scss';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserFriends } from '@fortawesome/free-solid-svg-icons'
import { faTasks } from '@fortawesome/free-solid-svg-icons'
import { faCalendarAlt } from '@fortawesome/free-solid-svg-icons'
import { faChartBar } from '@fortawesome/free-solid-svg-icons'
import { faCog } from '@fortawesome/free-solid-svg-icons'

const sideBar = props => (
    <nav className="sidebar">
        <ul className="sidebar__elements">
            <l1 className="sidebar__item">
                <FontAwesomeIcon icon={faUserFriends} size="lg" />
                <p className="sidebar__text">Manage</p>
            </l1>
            <l1 className="sidebar__item sidebar__item--active">
                <FontAwesomeIcon icon={faTasks} size="lg" />
                <p className="sidebar__text">Tasks</p>
            </l1>
            <l1 className="sidebar__item">
                <FontAwesomeIcon icon={faCalendarAlt} size="lg" />
                <p className="sidebar__text">Schedule</p>
            </l1>
            <l1 className="sidebar__item">
                <FontAwesomeIcon icon={faChartBar} size="lg" />
                <p className="sidebar__text">Reports</p>
            </l1>
        </ul>
        <ul className="sidebar__elements">
            <l1 className="sidebar__item">
                <FontAwesomeIcon icon={faCog} size="lg" />
                <p className="sidebar__text">Settings</p>
            </l1>
        </ul>
    </nav>
);

export default sideBar;