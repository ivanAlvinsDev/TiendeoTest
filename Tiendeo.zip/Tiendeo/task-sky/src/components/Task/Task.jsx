import React from 'react';
import '../Task/Task.scss'
import { Draggable } from 'react-beautiful-dnd';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faComment } from '@fortawesome/free-solid-svg-icons'
import { faPaperclip } from '@fortawesome/free-solid-svg-icons'
import { faUser } from '@fortawesome/free-solid-svg-icons'

export default class Task extends React.Component {
	render() {
		return (
			<Draggable draggableId={this.props.task.id} index={this.props.index} ContextId={this.props.ElementId}>
				{provided => (
					<div 
					className="task__container"
					ref={provided.innerRef}
					{...provided.draggableProps}
					{...provided.dragHandleProps}
					>
						<div className="task__priority">
							{this.props.task.priority}
						</div>
						<div className="task__content">
							{this.props.task.content}
						</div>
						<div className="task__footer">
							<div className="task__link-elements">
								<div className="task__link">
									<FontAwesomeIcon icon={faComment} />
									<div className="task__link-content">
										{this.props.task.messages}
									</div>
								</div>
								<div className="task__link">
									<FontAwesomeIcon icon={faPaperclip} />
									<div className="task__link-content">
										{this.props.task.attached}
									</div>
								</div>
							</div>
							<div className="task__user">
								<FontAwesomeIcon icon={faUser} />
							</div>
						</div>
					</div>
				)}
			</Draggable>
		)
	}
}