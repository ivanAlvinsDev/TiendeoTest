import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlus } from '@fortawesome/free-solid-svg-icons'
import './FabButton.scss';

const fabButton = props => (
    <button className="fabButton" onClick={props.click}>
        <FontAwesomeIcon icon={faPlus} size="lg" color="white" />
    </button>
);

export default fabButton;