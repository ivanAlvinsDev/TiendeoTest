import React from 'react';
import './Toolbar.scss';
import DrawerToggleButton from '../SideDrawer/DrawerToggleButton';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch } from '@fortawesome/free-solid-svg-icons'
import { faUser } from '@fortawesome/free-solid-svg-icons'
import { faBell } from '@fortawesome/free-solid-svg-icons'

const toolbar = props => (
    <header className="toolbar">
        <nav className="toolbar__navigation">
            <DrawerToggleButton click={props.drawerClickHandler} />
            <div className="toolbar__logo"><a href="logo">TaskSky</a></div>
            <div className="toolbar__navigation-items">
                <div className="toolbar__search">
                    <FontAwesomeIcon icon={faSearch} color="white" />
                    <div className="toolbar__search-content">Search for tasks...</div>
                </div>
                <ul className="toolbar__user-info">
                    <li className="toolbar__user-element">
                        <FontAwesomeIcon icon={faBell} color="white" />
                    </li>
                    <li className="toolbar__user-element">M. Thompson</li>
                    <li className="toolbar__user-element">
                        <div className="toolbar__user">
                            <FontAwesomeIcon icon={faUser} />
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
);

export default toolbar;