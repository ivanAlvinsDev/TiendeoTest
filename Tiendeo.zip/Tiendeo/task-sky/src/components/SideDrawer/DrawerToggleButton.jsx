import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
import './DrawerToggleButton.scss';

const drawerToggleButton = props => (
    <button className="toggle-button" onClick={props.click}>
        <FontAwesomeIcon icon={faBars} size="lg" color="white" />
    </button>
);

export default drawerToggleButton;