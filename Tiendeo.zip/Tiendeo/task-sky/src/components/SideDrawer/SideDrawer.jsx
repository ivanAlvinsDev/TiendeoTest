import React from 'react';
import './SideDrawer.scss';

const sideDrawer = props =>(
    <nav className="side-drawer">
        <ul className="side-drawer__items">
            <li className="side-drawer__link"><a href="Manage">Manage</a></li>
            <li className="side-drawer__link"><a href="Tasks">Tasks</a></li>
            <li className="side-drawer__link"><a href="Schedule">Schedule</a></li>
            <li className="side-drawer__link"><a href="Reports">Reports</a></li>
        </ul>
    </nav>
)

export default sideDrawer;